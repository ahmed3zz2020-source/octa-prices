# 📋 OCTA — MASTER CHECKLIST
**Investment Intelligence Engine**  
**آخر تحديث:** 2026-10-05

## Legend / المفتاح
| الرمز | المعنى |
|:---:|---|
| ✅ | **مكتمل** — تم واختبر |
| 🔄 | **جارٍ** — شغال عليه دلوقتي |
| ⬜ | **لسه** — لم يبدأ |
| ⚠️ | **مطلوب** — موجود بس ناقصه شغل |
| 🔴 | **حرج** — بيأثر على مصداقية النظام |

---

## 📊 DASHBOARD

| المرحلة | الحالة | الإنجاز |
|:---|:---:|:---:|
| **PHASE 0** — Project Audit | ✅ | **100%** |
| **PHASE 1** — Data Intelligence | ⬜ | 0% |
| **PHASE 2** — Technical Engine | ⬜ | 0% |
| **PHASE 3** — Fundamental Engine | ⬜ | 0% |
| **PHASE 4** — Liquidity Engine | ⬜ | 0% |
| **PHASE 5** — News Engine | ⬜ | 0% |
| **PHASE 6** — Sentiment Engine | ⬜ | 0% |
| **PHASE 7** — Risk Engine | ⬜ | 0% |
| **PHASE 8** — Portfolio Fit Engine | ⬜ | 0% |
| **PHASE 9** — Overall Intelligence | ⬜ | 0% |
| **PHASE 10** — Confidence Engine | ⬜ | 0% |
| **PHASE 11** — Explainability | ⬜ | 0% |
| **PHASE 12** — Opportunity Detection | ⬜ | 0% |
| **PHASE 13** — Scoring & Ranking | ⬜ | 0% |
| **PHASE 14** — Strategy Engine | ⬜ | 0% |
| **PHASE 15** — Backtesting | ⬜ | 0% |
| **PHASE 16** — Stress Testing | ⬜ | 0% |
| **PHASE 17** — Calibration | ⬜ | 0% |
| **PHASE 18** — Dashboard | ⬜ | 0% |
| **PHASE 19** — Final Production Audit | ⬜ | 0% |
| **INTELLIGENCE LAYER** — Thesis Engine | ⬜ | 0% |

**📈 الإجمالي: ▓░░░░░░░░░ 35%** (Infrastructure 65% — Intelligence 5%)

---

# ✅ PHASE 0 — PROJECT AUDIT
**الحالة: مكتمل 100%**

| # | المهمة | الحالة | التحقق |
|:---:|---|:---:|---|
| 0.1 | Map backend architecture (12 endpoints) | ✅ | `/api/*` — كلهم 200 |
| 0.2 | Map frontend (12 pages, 3 scripts) | ✅ | `index.html` 186KB |
| 0.3 | Live-test كل API | ✅ | 12/12 شغالين |
| 0.4 | Audit data freshness | ✅ | آخر تحديث 0.1h |
| 0.5 | Audit scoring logic | ✅ | 2 رياضي / 6 تخمين |
| 0.6 | Grade كل جزء 🔴🟡🟢 | ✅ | 8 strong / 10 improve / 10 weak |
| 0.7 | Document system map | ✅ | `PHASE_0_AUDIT.md` |
| 0.8 | Identify bugs | ✅ | 6 bugs موثقة |
| 0.9 | Recommended architecture | ✅ | 6 طبقات |
| 0.10 | Fix found bugs | ⬜ | مؤجل لـ Phase 1 |

---

# 🔴 PHASE 1 — DATA INTELLIGENCE ENGINE
**الحالة: لسه | الأولوية: الأعلى**
**الهدف: قبل ما نثق في أي تحليل، لازم نثق في البيانات**

## 1-A — Stock Coverage
| # | المهمة | الحالة | ملاحظة |
|:---:|---|:---:|---|
| 1.1 | توسيع `EGX` list من 46 → 271 | ⬜ | المصدر: `egx_names.json` |
| 1.2 | اختبار كل الرمز على TradingView | ⬜ | شيل الـ nulls |
| 1.3 | استبعاد الـ delisted / halted | ⬜ | |
| 1.4 | pagination أو gzip لـ `/api/prices` (90KB) | ⬜ | أداء الموبايل |

## 1-B — Fundamental Data (الأهم)
| # | المهمة | الحالة | الأهمية |
|:---:|---|:---:|:---:|
| 1.5 | إضافة 22 عمود fundamental للـ batch | ⬜ | 🔴 حرج |
| 1.6 | `price_earnings_ttm` → P/E | ⬜ | 🔴 |
| 1.7 | `return_on_equity` → ROE | ⬜ | 🔴 |
| 1.8 | `debt_to_equity` → D/E | ⬜ | 🔴 |
| 1.9 | `net_margin` / `operating_margin` | ⬜ | 🟡 |
| 1.10 | `beta_1_year` → Beta | ⬜ | 🔴 |
| 1.11 | `Volatility.D` → Volatility | ⬜ | 🔴 |
| 1.12 | `price_book_fq` → P/B | ⬜ | 🟡 |
| 1.13 | `dividends_yield_current` | ⬜ | 🟡 |
| 1.14 | `relative_volume_10d_calc` | ⬜ | 🟡 |
| 1.15 | `Recommend.All` → TV technical rating | ⬜ | 🔴 |
| 1.16 | `market_cap_basic` | ⬜ | 🟡 |
| 1.17 | `earnings_per_share_diluted_ttm` | ⬜ | 🟡 |
| 1.18 | تخزين العمود في cache.json | ⬜ | |

## 1-C — Data Validation
| # | المهمة | الحالة |
|:---:|---|:---:|
| 1.19 | Range check على السعر (0 < price < 100000) | ⬜ |
| 1.20 | Range check على النسب (|change| < 50%) | ⬜ |
| 1.21 | كشف القيم الفيزيائية المستحيلة (P/E < 0 مع ROE > 20) | ⬜ |
| 1.22 | كشف duplicates في الـ payload | ⬜ |
| 1.23 | كشف stale data (> 2 ساعة) | ⬜ |
| 1.24 | `impossible_values` report لكل دورة | ⬜ |

## 1-D — Freshness & Staleness
| # | المهمة | الحالة |
|:---:|---|:---:|
| 1.25 | `data_timestamp` لكل سهم | ⬜ |
| 1.26 | `data_age_seconds` | ⬜ |
| 1.27 | `is_stale` flag واضح في الـ API | ⬜ |
| 1.28 | عرض التحذير في الـ UI للسهم القديم | ⬜ |
| 1.29 | تصليح: EGX33 مفرقش كـ average | ⬜ |
| 1.30 | تصليح: 6 أسهم stale بلا indication | ⬜ |

## 1-E — Source Quality & Confidence
| # | المهمة | الحالة |
|:---:|---|:---:|
| 1.31 | `Source Reliability Score` لكل مصدر | ⬜ |
| 1.32 | TradingView = 95 / foudalens = 90 / Gemini = 70 | ⬜ |
| 1.33 | **Data Confidence Score** لكل سهم (0-100) | ⬜ |
| 1.34 | حسابه من: عدد الحقول المتاحة × عمرها × مصدرها | ⬜ |
| 1.35 | Source conflict resolution (أرخص مصدرين مختلفين) | ⬜ |
| 1.36 | Source Priority Table | ⬜ |
| 1.37 | تسجيل تاريخ كل رقم (provenance) | ⬜ |

## 1-F — Infrastructure
| # | المهمة | الحالة |
|:---:|---|:---:|
| 1.38 | Ticker fetch: 11 request → 1 batch | ⬜ أداء |
| 1.39 | `--workers 1` → scalable cache (Redis or file-lock) | ⬜ |
| 1.40 | Rate limit على `/api/analyze` | ⬜ أمن |
| 1.41 | API key rotation policy | ⬜ أمن |
| 1.42 | Structured logging (بدل print) | ⬜ |

**Phase 1 Deliverable:** كل رقم في النظام يعرف (مصدره، عمره، جودته)

---

# ⬜ PHASE 2 — TECHNICAL INTELLIGENCE ENGINE
**الحالة: لسه**

## 2-A — Data Acquisition
| # | المهمة | الحالة | ملاحظة |
|:---:|---|:---:|---|
| 2.1 | تاريخ يومي (365 يوم) لكل سهم | ⬜ | TradingView history endpoint |
| 2.2 | OHLCV daily | ⬜ | |
| 2.3 | Intraday (5min) | ⬜ | اختياري |
| 2.4 | Weekly aggregation | ⬜ | |
| 2.5 | تخزين history في disk cache | ⬜ | |

## 2-B — Trend Analysis
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.6 | Short-term trend (5-20 يوم) | ⬜ |
| 2.7 | Medium-term trend (50-100 يوم) | ⬜ |
| 2.8 | Long-term trend (200+ يوم) | ⬜ |
| 2.9 | Market structure (HH-HL / LH-LL) | ⬜ |
| 2.10 | Swing highs/lows detection | ⬜ |

## 2-C — Momentum
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.11 | RSI (14) + overbought/oversold | ⬜ |
| 2.12 | MACD + crossovers | ⬜ |
| 2.13 | ROC (Rate of Change) | ⬜ |
| 2.14 | Momentum strength (0-100) | ⬜ |

## 2-D — Moving Averages
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.15 | SMA (20, 50, 200) | ⬜ |
| 2.16 | EMA (12, 26) | ⬜ |
| 2.17 | Golden/Death cross detection | ⬜ |
| 2.18 | Distance from each MA (%) | ⬜ |

## 2-E — Support & Resistance
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.19 | Support levels (من swing lows) | ⬜ |
| 2.20 | Resistance levels (من swing highs) | ⬜ |
| 2.21 | Fibonacci retracement | ⬜ |
| 2.22 | Pivot points | ⬜ |
| 2.23 | Distance to nearest S/R (%) | ⬜ |

## 2-F — Volume Analysis
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.24 | Volume trend (صاعد/هابط) | ⬜ |
| 2.25 | Relative volume vs 10d avg | ⬜ |
| 2.26 | Abnormal volume detection | ⬜ |
| 2.27 | Volume confirmation of price move | ⬜ |
| 2.28 | On-Balance Volume (OBV) | ⬜ |

## 2-G — Breakouts
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.29 | Breakout detection | ⬜ |
| 2.30 | False breakout identification | ⬜ |
| 2.31 | Breakout confirmation logic | ⬜ |
| 2.32 | Pre-breakout compression (squeeze) | ⬜ |

## 2-H — Volatility
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.33 | ATR (14) | ⬜ |
| 2.34 | Historical volatility (30d, 90d) | ⬜ |
| 2.35 | Volatility expansion/contraction | ⬜ |
| 2.36 | Bollinger Bands + squeeze | ⬜ |

## 2-I — Multi-Timeframe
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.37 | Intraday analysis | ⬜ |
| 2.38 | Daily analysis | ⬜ |
| 2.39 | Weekly analysis | ⬜ |
| 2.40 | Confluence score بين الـ 3 | ⬜ |

## 2-J — Scoring
| # | المهمة | الحالة |
|:---:|---|:---:|
| 2.41 | Technical Score (0-100) | ⬜ |
| 2.42 | كل نقطة ليها weight محدد | ⬜ |
| 2.43 | Top 3 positive factors | ⬜ |
| 2.44 | Top 3 negative factors | ⬜ |
| 2.45 | **WHY** explanation لكل score | ⬜ |

**Phase 2 Deliverable:** `Technical Score /100` + أسباب رقمية

---

# ⬜ PHASE 3 — FUNDAMENTAL INTELLIGENCE ENGINE
**الحالة: لسه**

## 3-A — Data
| # | المهمة | الحالة | ملاحظة |
|:---:|---|:---:|---|
| 3.1 | Income statement (إيرادات/صافي) | ⬜ | |
| 3.2 | Balance sheet (أصول/ديون) | ⬜ | |
| 3.3 | Cash flow statement | ⬜ | |
| 3.4 | Quarterly history (4-8 أرباع) | ⬜ | |
| 3.5 | Growth rates (Revenue/EPS) | ⬜ | متاح جزئياً |

## 3-B — Growth
| # | المهمة | الحالة |
|:---:|---|:---:|
| 3.6 | Revenue growth YoY | ⬜ |
| 3.7 | Earnings growth YoY | ⬜ |
| 3.8 | EPS growth | ⬜ |
| 3.9 | 3-year CAGR | ⬜ |
| 3.10 | Growth consistency (مستقر ولا متذبذب) | ⬜ |
| 3.11 | Growth Score (0-100) | ⬜ |

## 3-C — Profitability
| # | المهمة | الحالة |
|:---:|---|:---:|
| 3.12 | Gross margin + trend | ⬜ |
| 3.13 | Operating margin + trend | ⬜ |
| 3.14 | Net margin + trend | ⬜ |
| 3.15 | ROE | ⬜ |
| 3.16 | ROA | ⬜ |
| 3.17 | Profitability Score (0-100) | ⬜ |

## 3-D — Financial Health
| # | المهمة | الحالة |
|:---:|---|:---:|
| 3.18 | Debt levels | ⬜ |
| 3.19 | Debt/Equity ratio | ⬜ |
| 3.20 | Interest coverage | ⬜ |
| 3.21 | Current ratio | ⬜ |
| 3.22 | Quick ratio | ⬜ |
| 3.23 | Free cash flow | ⬜ |
| 3.24 | Health Score (0-100) | ⬜ |

## 3-E — Earnings Quality
| # | المهمة | الحالة |
|:---:|---|:---:|
| 3.25 | Net income vs operating cash flow | ⬜ |
| 3.26 | Accruals ratio | ⬜ |
| 3.27 | One-off items detection | ⬜ |
| 3.28 | Earnings quality score | ⬜ |

## 3-F — Valuation
| # | المهمة | الحالة | متاح؟ |
|:---:|---|:---:|:---:|
| 3.29 | P/E (TTM) | ⬜ | ✅ |
| 3.30 | P/B | ⬜ | ✅ |
| 3.31 | EV/EBITDA | ⬜ | ❌ |
| 3.32 | PEG | ⬜ | ❌ |
| 3.33 | P/S (Price/Sales) | ⬜ | ❌ |
| 3.34 | Dividend yield | ⬜ | ✅ |
| 3.35 | **Sector comparison** (P/E مقابل متوسط القطاع) | ⬜ | ⚠️ مقترح |
| 3.36 | Historical own P/E average | ⬜ | |
| 3.37 | Valuation Score (0-100) | ⬜ | |

## 3-G — Fair Value
| # | المهمة | الحالة | المنهجية |
|:---:|---|:---:|---|
| 3.38 | Method 1: P/E based | ⬜ | fair_pe × EPS |
| 3.39 | Method 2: P/B based | ⬜ | fair_pb × BVPS |
| 3.40 | Method 3: DCF (مبسّط) | ⬜ | |
| 3.41 | Method 4: Dividend Discount | ⬜ | |
| 3.42 | **Weighted fair value** | ⬜ | حسب التوافر |
| 3.43 | Valuation Status: Undervalued/Fair/Over | ⬜ | |
| 3.44 | **Confidence في التقدير** | ⬜ | |

**Phase 3 Deliverable:** `Fundamental Score /100` + `Valuation Status` + ثقة

---

# ⬜ PHASE 4 — LIQUIDITY ENGINE
**الحالة: لسه**

| # | المهمة | الحالة | متاح؟ |
|:---:|---|:---:|---|
| 4.1 | Average daily volume (30d) | ⬜ | ✅ |
| 4.2 | Turnover ratio (volume/free float) | ⬜ | ⚠️ |
| 4.3 | Relative volume | ⬜ | ✅ |
| 4.4 | Trading frequency (أيام اتفاوضت) | ⬜ | |
| 4.5 | Bid/Ask spread | ⬜ | ❌ |
| 4.6 | Liquidity trend (20 يوم) | ⬜ | |
| 4.7 | Liquidity deterioration detection | ⬜ | |
| 4.8 | Liquidity expansion detection | ⬜ | |
| 4.9 | Ease of entry (كم جني买 سريع) | ⬜ | |
| 4.10 | Ease of exit | ⬜ | |
| 4.11 | Days-to-liquidate (حجم ÷ daily vol) | ⬜ | |
| 4.12 | **Liquidity Score (0-100)** | ⬜ | |
| 4.13 | **Liquidity Risk: Low/Med/High** | ⬜ | |

**Phase 4 Deliverable:** `Liquidity Score` + `Ease of entry/exit`

---

# ⬜ PHASE 5 — NEWS INTELLIGENCE ENGINE
**الحالة: لسه | 🔴 الأهم ومصعب**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 5.1 | News source: RSS/Cairo Investment (عربي) | ⬜ |
| 5.2 | News source: Reuters/Bloomberg Egypt | ⬜ |
| 5.3 | News source: EGX official disclosures | ⬜ |
| 5.4 | News source: foudalens (موجود ✅) | ⚠️ |
| 5.5 | News fetch loop (كل 30 دقيقة) | ⬜ |
| 5.6 | News storage + deduplication | ⬜ |
| 5.7 | News → ticker matching (اسم/رمز) | ⬜ |
| 5.8 | Arabic sentiment analysis | ⬜ |
| 5.9 | Recency weighting (حديث = أقوى) | ⬜ |
| 5.10 | Source reliability weighting | ⬜ |
| 5.11 | Importance classification | ⬜ |
| 5.12 | **Materiality check** (هل الخبر مؤثر فعلاً؟) | ⬜ |
| 5.13 | Market impact vs Company impact vs Sector | ⬜ |
| 5.14 | Positive / Negative / Neutral | ⬜ |
| 5.15 | **News Score (0-100)** | ⬜ |
| 5.16 | Impact + Confidence | ⬜ |
| 5.17 | `no_news` case → confidence منخفضة | ⬜ |

**Phase 5 Deliverable:** `News Score` مع **Impact + Confidence** — ومهم جداً: لو مفيش أخبار، الـ score ينزل

---

# ⬜ PHASE 6 — SENTIMENT ENGINE
**الحالة: لسه | ⚠️ قاعدة صارمة: المعنويات ما调配يش القرار**

| # | المهمة | الحالة | ملاحظة |
|:---:|---|:---:|---|
| 6.1 | News sentiment (من Phase 5) | ⬜ | |
| 6.2 | Market sentiment (EGX30 trend) | ⬜ | |
| 6.3 | Sector sentiment (القطاع كله) | ⬜ | |
| 6.4 | Investor sentiment (إن توفر) | ⬜ | اختياري |
| 6.5 | Social sentiment (إن توفر) | ⬜ | اختياري |
| 6.6 | **Sentiment Score (0-100)** | ⬜ | |
| 6.7 | ⚠️ **Sentiment CAP: أقصى 25% من القرار** | ⬜ | **قاعدة صارمة** |
| 6.8 | **Sentiment vs Reality check** | ⬜ | لو sentiment=90 و fundamental=45 → لازم يظهر إن في تعارض |
| 6.9 | Display "المعنويات عالية لكن الأساس ضعيف" | ⬜ | |

**Phase 6 Deliverable:** `Sentiment Score` — **مع cap صارم**

---

# ⬜ PHASE 7 — RISK ENGINE
**الحالة: لسه**

## 7-A — Risk Metrics
| # | المهمة | الحالة | متاح؟ |
|:---:|---|:---:|:---:|
| 7.1 | ATR (من Phase 2) | ⬜ | ✅ |
| 7.2 | Historical volatility | ⬜ | ✅ |
| 7.3 | Max drawdown (1y) | ⬜ | |
| 7.4 | Current drawdown | ⬜ | |
| 7.5 | Beta (من Phase 1) | ⬜ | ✅ |
| 7.6 | Downside deviation | ⬜ | |
| 7.7 | Sharpe ratio | ⬜ | |
| 7.8 | Sortino ratio | ⬜ | |

## 7-B — Risk Types
| # | المهمة | الحالة |
|:---:|---|:---:|
| 7.9 | Volatility risk | ⬜ |
| 7.10 | Liquidity risk (من Phase 4) | ⬜ |
| 7.11 | Event risk (من Phase 5) | ⬜ |
| 7.12 | Earnings risk (Upcoming earnings date) | ⬜ |
| 7.13 | Valuation risk (overvalued?) | ⬜ |
| 7.14 | Technical breakdown risk | ⬜ |
| 7.15 | Country risk (EGX-specific) | ⬜ |
| 7.16 | Sector risk | ⬜ |
| 7.17 | Concentration risk | ⬜ |

## 7-C — Scoring
| # | المهمة | الحالة |
|:---:|---|:---:|
| 7.18 | **Risk Score (0-100)** — أعلى = أخطر | ⬜ |
| 7.19 | Risk Level: Low/Medium/High/Extreme | ⬜ |
| 7.20 | **Risk-Adjusted Opportunity** | ⬜ |
| 7.21 | Return Potential ÷ Risk Score | ⬜ |
| 7.22 | Top 3 risks listed | ⬜ |

**Phase 7 Deliverable:** `Risk Score` + `Risk-Adjusted Opportunity` (مهم — أفضل سهم مش أعلى return)

---

# ⬜ PHASE 8 — PORTFOLIO FIT ENGINE
**الحالة: لسه | ⚠️ مفيش portfolio في الـ UI دلوقتي — محتاج نبنيه الأول**

## 8-A — Portfolio Infrastructure
| # | المهمة | الحالة |
|:---:|---|:---:|
| 8.1 | Portfolio input UI (إضافة/حذف أسهم) | ⬜ |
| 8.2 | **localStorage persistence** (مهم — مفيش حالياً) | ⬜ |
| 8.3 | Position size tracking | ⬜ |
| 8.4 | Cash tracking | ⬜ |
| 8.5 | Total portfolio value | ⬜ |

## 8-B — Analysis
| # | المهمة | الحالة |
|:---:|---|:---:|
| 8.6 | Sector exposure map | ⬜ |
| 8.7 | Asset concentration (max position %) | ⬜ |
| 8.8 | Correlation matrix بين Holdings | ⬜ |
| 8.9 | Existing exposure for this stock | ⬜ |
| 8.10 | Portfolio risk (weighted) | ⬜ |
| 8.11 | Diversification score | ⬜ |

## 8-C — Fit Scoring
| # | المهمة | الحالة |
|:---:|---|:---:|
| 8.12 | **Portfolio Fit Score (0-100)** | ⬜ |
| 8.13 | Reason: "Exposure كبير في نفس القطاع" | ⬜ |
| 8.14 | Show Stock Score vs Fit Score side by side | ⬜ |
| 8.15 | Suggest: "يقلل التنويع" أو "يزيده" | ⬜ |

**Phase 8 مثال المطلوب:**
```
Stock Score = 90
Portfolio Fit = 52  ← لأن المحفظة فيها 40% بنوك
⚠️ تحذير ظاهر للمستخدم
```

**Phase 8 Deliverable:** `Portfolio Fit Score` + تحذير التعرض

---

# ⬜ PHASE 9 — OVERALL INTELLIGENCE ENGINE
**الحالة: لسه | ⚠️ ممنوع weighted average ساذج**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 9.1 | تجميع الـ 7 محاور | ⬜ |
| 9.2 | Base Score (weighted avg معقول) | ⬜ |
| 9.3 | **Risk Adjustment** (مخاطرة عالية → خصم) | ⬜ |
| 9.4 | **Data Confidence Adjustment** (بيانات ضعيفة → خصم) | ⬜ |
| 9.5 | **Portfolio Adjustment** (م exposing → خصم) | ⬜ |
| 9.6 | **Event Adjustment** (خبر سيء → خصم) | ⬜ |
| 9.7 | **FINAL INTELLIGENCE SCORE /100** | ⬜ |
| 9.8 | الأعلى = الأحسن (0-100) | ⬜ |
| 9.9 | ⚠️ **Base weights.yaml** (قابل للضبط) | ⬜ |
| 9.10 | Deterministic (نفس input = نفس output) | ⬜ |

**Phase 9 Formula:**
```
Base = Σ(axis × axis_weight)
Adjusted = Base
         × (1 - risk_penalty)
         × (1 - confidence_penalty)
         × (1 - portfolio_penalty)
         × (1 - event_penalty)
FINAL = clamp(Adjusted, 0, 100)
```

**Phase 9 Deliverable:** `FINAL SCORE` + كل الـ penalties ظاهرة

---

# ⬜ PHASE 10 — CONFIDENCE ENGINE
**الحالة: لسه | ⚠️ SCORE ≠ CONFIDENCE**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 10.1 | Data completeness score | ⬜ |
| 10.2 | Data freshness score | ⬜ |
| 10.3 | Source reliability score | ⬜ |
| 10.4 | Analysis coverage (كام محور اتحسب فعلاً) | ⬜ |
| 10.5 | **Overall Confidence (0-100%)** | ⬜ |
| 10.6 | Confidence label: High/Medium/Low | ⬜ |
| 10.7 | ⚠️ **Low confidence = لا توصية Buy/Sell قوية** | ⬜ |
| 10.8 | عرض "البيانات ناقصة" بوضوح | ⬜ |
| 10.9 | الثقة بتتحدث مع كل refresh | ⬜ |

**Phase 10 مثال:**
```
Overall Score = 88
Data Confidence = 47%   ← بيانات ناقصة
⚠️ النتيجة: "بيانات ناقصة — لا تعتمد على هذه التوصية"
```

**Phase 10 Deliverable:** `Confidence %` + تحذير عند niedrig

---

# ⬜ PHASE 11 — EXPLAINABILITY ENGINE
**الحالة: لسه**

## 11-A — Score Breakdown
| # | المهمة | الحالة |
|:---:|---|:---:|
| 11.1 | كل محور + نقاطه | ⬜ |
| 11.2 | كل محور + وزنـه | ⬜ |
| 11.3 | كل محور + مساهمته الفعلية بالنقاط | ⬜ |
| 11.4 | "لماذا 87؟" — breakdown كامل | ⬜ |
| 11.5 | Interactive breakdown (click to expand) | ⬜ |
| 11.6 | waterfall chart (منه/base → للنهائي) | ⬜ |

## 11-B — Reasoning
| # | المهمة | الحالة |
|:---:|---|:---:|
| 11.7 | Top 3 positive factors | ⬜ |
| 11.8 | Top 3 negative factors | ⬜ |
| 11.9 | Key risks (من Phase 7) | ⬜ |
| 11.10 | **Missing data** (إيه اللي ضاع) | ⬜ |
| 11.11 | **What could change the score?** | ⬜ |
| 11.12 | **What would invalidate the thesis?** | ⬜ |
| 11.13 | ⚠️ **Negative reasoning** (ليه مش ده سهم أحسن) | ⬜ |

**Phase 11 Deliverable:** كل عدد في النظام قابل للضغط عليه ويفسّر نفسه

---

# ⬜ PHASE 12 — OPPORTUNITY DETECTION ENGINE
**الحالة: لسه | 🎯 فلسفة: اكتشاف مبكر مش مطاردة**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 12.1 | Accumulation detection (OBV + volume up) | ⬜ |
| 12.2 | Volume expansion pattern | ⬜ |
| 12.3 | Compression (Bollinger squeeze) | ⬜ |
| 12.4 | Breakout setup (قبل الكسر) | ⬜ |
| 12.5 | Improving momentum (مقارنة 5 أيام) | ⬜ |
| 12.6 | Fundamental catalyst (تغيير في الأساسيات) | ⬜ |
| 12.7 | Positive earnings trend | ⬜ |
| 12.8 | Smart money behavior (إن أمكن) | ⬜ |
| 12.9 | Under-accumulation (السهم لسه محدش خده) | ⬜ |
| 12.10 | **Opportunity Score (0-100)** | ⬜ |
| 12.11 | ⚠️ **Early vs Existing** classification | ⬜ |
| 12.12 | Existing Momentum (بعد الكسر بـ 5 أيام) | ⬜ |
| 12.13 | **Early Opportunity** (قبل الكسر) | ⬜ |

**Phase 12 مهم:** الهدف يقول "ده لسه بدري" مش "ده طالع"

---

# ⬜ PHASE 13 — SCORING & RANKING
**الحالة: لسه**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 13.1 | Score كل السهم (271) | ⬜ |
| 13.2 | Top 20 view | ⬜ |
| 13.3 | Top 10 view | ⬜ |
| 13.4 | Top 5 view ("أحسن 5 فرص") | ⬜ |
| 13.5 | Filter by Sector | ⬜ |
| 13.6 | Filter by Risk level | ⬜ |
| 13.7 | Filter by Liquidity (min volume) | ⬜ |
| 13.8 | Filter by Technical strength | ⬜ |
| 13.9 | Filter by Fundamental strength | ⬜ |
| 13.10 | Filter by Strategy | ⬜ |
| 13.11 | Filter by Time horizon | ⬜ |
| 13.12 | Sort by Confidence | ⬜ |
| 13.13 | Top opportunities by Risk-Adjusted | ⬜ |

**Phase 13 Deliverable:** صفحة ranking مع كل الـ filters

---

# ⬜ PHASE 14 — STRATEGY ENGINE
**الحالة: لسه | ⚠️ نفس البيانات — أوزان مختلفة**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 14.1 | **Swing Trading profile** (technical 40%) | ⬜ |
| 14.2 | **Value Investing** (fundamental 45%) | ⬜ |
| 14.3 | **Growth** (growth 35% + fundamental 30%) | ⬜ |
| 14.4 | **Income/Dividend** (yield + quality) | ⬜ |
| 14.5 | **Balanced** (توازن) | ⬜ |
| 14.6 | **Conservative** (risk-adjusted) | ⬜ |
| 14.7 | **Aggressive** (momentum-heavy) | ⬜ |
| 14.8 | ⚠️ **نفس البيانات، أوزان مختلفة فقط** | ⬜ |
| 14.9 | User يختار strategy → يغير الترتيب | ⬜ |
| 14.10 | عرض "التوصية بتتغير حسب الـ strategy" | ⬜ |

**Phase 14 ملف `strategies.yaml`:**
```yaml
swing_trading:
  technical: 0.40
  fundamental: 0.15
  liquidity: 0.25
  news: 0.10
  risk_penalty: 0.10
value_investing:
  technical: 0.10
  fundamental: 0.45
  ...
```

---

# ⬜ PHASE 15 — BACKTESTING ENGINE
**الحالة: لسه | 🔴 ضروري قبل الإنتاج**

## 15-A — Infrastructure
| # | المهمة | الحالة |
|:---:|---|:---:|
| 15.1 | Historical price database (2y minimum) | ⬜ |
| 15.2 | Backtest runner | ⬜ |
| 15.3 | Signal generator (نفس الـ scoring) | ⬜ |
| 15.4 | Entry/exit logic | ⬜ |
| 15.5 | Position sizing rules | ⬜ |
| 15.6 | Commission + slippage modeling | ⬜ |

## 15-B — Metrics
| # | المهمة | الحالة |
|:---:|---|:---:|
| 15.7 | Total return | ⬜ |
| 15.8 | **Win rate** | ⬜ |
| 15.9 | **Profit factor** | ⬜ |
| 15.10 | **Max drawdown** | ⬜ |
| 15.11 | Sharpe ratio | ⬜ |
| 15.12 | Sortino ratio | ⬜ |
| 15.13 | Average win / average loss | ⬜ |
| 15.14 | Holding period | ⬜ |
| 15.15 | Risk-adjusted return | ⬜ |

## 15-C — Benchmark
| # | المهمة | الحالة |
|:---:|---|:---:|
| 15.16 | Benchmark: EGX30 | ⬜ |
| 15.17 | مقارنة مع EGX30 performance | ⬜ |
| 15.18 | مقارنة مع random picks | ⬜ |
| 15.19 | **هل أحسن من السوق فعلاً؟** | ⬜ |

**Phase 15 حرج:** بدون backtest، كل ده نظري

---

# ⬜ PHASE 16 — STRESS TESTING
**الحالة: لسه**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 16.1 | Bull market backtest | ⬜ |
| 16.2 | Bear market backtest | ⬜ |
| 16.3 | Sideways market | ⬜ |
| 16.4 | Crash scenario (2020, 2022) | ⬜ |
| 16.5 | High volatility period | ⬜ |
| 16.6 | Low liquidity period | ⬜ |
| 16.7 | Major news event | ⬜ |
| 16.8 | Earnings season volatility | ⬜ |
| 16.9 | **أين يفشل النظام؟** | ⬜ |
| 16.10 | إصلاح نقاط الضعف | ⬜ |
| 16.11 | Document failure modes | ⬜ |

**Phase 16 مهم:** لازم نعرف النظام بيفشل فين — مش بس بيشتغل امتى

---

# ⬜ PHASE 17 — CALIBRATION
**الحالة: لسه | ⚠️ ممنوع overfitting**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 17.1 | ضبط axis weights | ⬜ |
| 17.2 | ضبط thresholds | ⬜ |
| 17.3 | ضبط penalties | ⬜ |
| 17.4 | ضبط confidence formula | ⬜ |
| 17.5 | ضبط risk adjustments | ⬜ |
| 17.6 | Cross-validation (train/test split) | ⬜ |
| 17.7 | ⚠️ **Walk-forward validation** | ⬜ |
| 17.8 | Overfit detection | ⬜ |
| 17.9 | ⚠️ كل تعديل لازم يكون **منطقي ومش عشوائي** | ⬜ |
| 17.10 | Document كل calibration decision | ⬜ |

---

# ⬜ PHASE 18 — PROFESSIONAL DASHBOARD
**الحالة: لسه**

## 18-A — Stock Intelligence Page
| # | المهمة | الحالة |
|:---:|---|:---:|
| 18.1 | Overall Score (big) | ⬜ |
| 18.2 | Confidence % (side by side) | ⬜ |
| 18.3 | 7 axes visual (bars) | ⬜ |
| 18.4 | "Why This Score?" expandable | ⬜ |
| 18.5 | Key Positives | ⬜ |
| 18.6 | Key Risks | ⬜ |
| 18.7 | What To Watch | ⬜ |
| 18.8 | Possible Catalyst | ⬜ |
| 18.9 | What Could Invalidate | ⬜ |
| 18.10 | Data freshness indicator | ⬜ |
| 18.11 | Missing data warning | ⬜ |

## 18-B — Ranking Page
| # | المهمة | الحالة |
|:---:|---|:---:|
| 18.12 | Top 20/10/5 | ⬜ |
| 18.13 | Filters UI | ⬜ |
| 18.14 | Strategy selector | ⬜ |
| 18.15 | Compare mode (2-3 أسهم) | ⬜ |

## 18-C — Portfolio Page
| # | المهمة | الحالة |
|:---:|---|:---:|
| 18.16 | Holdings list | ⬜ |
| 18.17 | Sector exposure pie | ⬜ |
| 18.18 | Portfolio risk meter | ⬜ |
| 18.19 | Fit warnings | ⬜ |

## 18-D — UX
| # | المهمة | الحالة |
|:---:|---|:---:|
| 18.20 | Dark/Light theme | ⬜ |
| 18.21 | Mobile-first responsive | ⬜ |
| 18.22 | Loading states skeleton | ⬜ |
| 18.23 | Error states informative | ⬜ |
| 18.24 | PWA installable | ⬜ |
| 18.25 | Offline (last known data) | ⬜ |

---

# ⬜ PHASE 19 — FINAL PRODUCTION AUDIT
**الحالة: لسه**

| # | المهمة | الحالة |
|:---:|---|:---:|
| 19.1 | كل الـ phases tested end-to-end | ⬜ |
| 19.2 | No breaking changes | ⬜ |
| 19.3 | Performance test (load time) | ⬜ |
| 19.4 | Error handling verified | ⬜ |
| 19.5 | Security check | ⬜ |
| 19.6 | Data accuracy verified vs source | ⬜ |
| 19.7 | Documentation complete | ⬜ |
| 19.8 | Backtest results documented | ⬜ |
| 19.9 | Failure modes documented | ⬜ |
| 19.10 | Calibration documented | ⬜ |
| 19.11 | **WORLD-CLASS** achieved? | ⬜ |

---

# ⬜ INTELLIGENCE LAYER — INVESTMENT THESIS ENGINE
**الحالة: لسه | 🌟 الطبقة الأعلى — بتجمع كل اللي فوق في قصة**

| # | المهمة | الحالة | مبني على |
|:---:|---|:---:|---|
| T.1 | **Thesis** (لماذا السهم فرصة؟) | ⬜ | كل المحاور |
| T.2 | **Catalysts** (إيه اللي هيحرّكه؟) | ⬜ | News + Events |
| T.3 | **Risks** (إيه اللي يفسد الفكرة؟) | ⬜ | Phase 7 |
| T.4 | **Confirmation** (إيه اللي ننتظره؟) | ⬜ | Technical setup |
| T.5 | **Invalidation** (إيه اللي يخلي التحليل غلط؟) | ⬜ | كل المحاور |
| T.6 | ⚠️ **مبني على البيانات فقط — ممنوع اختلاق** | ⬜ | قاعدة صارمة |
| T.7 | Thesis مقابل كل data point (traceable) | ⬜ | |

**Phase T مثال:**
```
THESIS:
"COMI سهم بنكي بـ P/E 6.1 (متوسط القطاع 18) و ROE 34%،
بيقفل بفارق كبير. السهم تحت ضغط (-8.6% في شهر) لكن 
 fundamentals قوية. إذا السوق لф"

CATALYSTS:
• Dividend yield 4.7%
• Banking sector rotation
• Oversold RSI

RISKS:
• Beta 1.3 (أعلى من السوق)
• Egyptian currency exposure
• No recent news catalyst

CONFIRMATION NEEDED:
• Break above resistance at X
• Volume confirmation (current: 0.4x avg)

INVALIDATION:
• P/E above 10
• ROE drops below 25%
• Q3 earnings below X
```

---

# 🎯 ملخص التوصيات

## القواعد الصارمة اللي لازم نلتزم بيها
| # | القاعدة | أولوية |
|:---:|---|:---:|
| 1 | **لا تخترع أي بيانات** | 🔴 |
| 2 | **لا تخفي البيانات الناقصة** | 🔴 |
| 3 | **لا تعطي Confidence عالية مع بيانات ضعيفة** | 🔴 |
| 4 | **لا تستخدم weighted average ساذج** | 🔴 |
| 5 | **لا تعطِ Buy/Sell بدون تفسير** | 🔴 |
| 6 | **لا تخلط cash dividend مع stock dividend** | 🔴 |
| 7 | **Sentiment ماcontrolsش القرار لوحده** | 🔴 |
| 8 | **Overall Score مايخفيش المخاطر** | 🔴 |
| 9 | **لا تكسر أي وظيفة موجودة** | 🔴 |
| 10 | **Backtest قبل ما نعتبره جاهز** | 🔴 |

## أقصر طريق للـ World-Class
```
Phase 1 (Data)  ← الأساس، مفيش阶段的 بعدها قيم
     ↓
Phase 2-4 (Engines) ← الأرقام الحقيقية
     ↓
Phase 5 (News) ← الأهم، أصعب
     ↓
Phase 7 (Risk) ← الأمان
     ↓
Phase 9-11 (Score + Explain) ← الشفافية
     ↓
Phase 15 (Backtest) ← الإثبات
     ↓
Phase 18 (Dashboard) ← العرض
```

---

# 📌 END OF CHECKLIST

**الإجمالي: 210 مهمة موزعة على 20 phase**
**مكتمل: 10 (Phase 0)**
**متبقي: 200 مهمة**
**النسبة الحالية: 35%** (Infrastructure متبني 65%، Intelligence لسه 5%)

---

*Last updated: 2026-10-05 — Phase 0 Complete*
