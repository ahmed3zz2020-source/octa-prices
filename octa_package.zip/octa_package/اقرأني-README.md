# 🐙 OCTA — Investment Intelligence Engine
## ملف التسليم الكامل — للإرسال على تليجرام / حفظ على الجهاز

```
📅 تاريخ التسليم: 2026-10-07
🔖 آخر commit: 33533f7
✅ الحالة: 19/19 مرحلة مكتملة — 34/34 endpoint شغال
```

---

## 🚨 لو فتحت الشات ده... اقرأ الأول

```
إنت ماشي تكمل مشروع OCTA.
الملف ده فيه آخر حالة. اقرأ PROJECT_STATE.md و CHECKLIST.md الأول.
شغّل ./check_health.sh قبل أي تعديل.
ما تعملش amend على update_prices.py — كل تعديل في commit واحد.
```

---

## 📦 محتويات الملف

| الملف | الحجم | الوصف |
|:---|---:|---|
| `update_prices.py` | 213KB | **الـ backend كامل** — 4537 سطر، 38 endpoint |
| `index.html` | 244KB | **الـ frontend كامل** — 227KB، 12 صفحة |
| `div_actions.py` | 10KB | جالب التوزيعات والإعلانات الرسمية |
| `egx_names.json` | 22KB | 271 سهم بأسمائها العربية وقطاعاتها |
| `egx_names.py` | 1.4KB | محمّل الأسماء |
| `requirements.txt` | 47B | flask + requests + gunicorn |
| `Procfile` | 79B | أمر التشغيل |
| `check_health.sh` | 1.2KB | **فحص السلامة — شغّله قبل أي تعديل** |
| `PROJECT_STATE.md` | 5.3KB | حالة المشروع التفصيلية |
| `CHECKLIST.md` | 30KB | خطة الـ 19 مرحلة بالتفصيل |

---

## 🌐 الروابط المهمة

| | |
|:---|:---|
| **الموقع** | `https://jxvfkm8kpnrtz.space.minimax.io` |
| **الـ API** | `https://octa-prices-production-4ccb.up.railway.app` |
| **الريبو** | `https://github.com/ahmed3zz2020-source/octa-prices` |
| **Railway** | `https://railway.com/project/345f503b-9d38-452f-917b-fd276b9ff671` |

---

## ⚙️ الـ Backend

### الـ endpoints الـ 38

```bash
# الأساسيات
GET  /                          → حالة الخدمة
GET  /api/prices                → كل الأسعار (252 سهم)
GET  /api/ticker                → 12 مؤشر (ذهب/دولار/نفط/مؤشرات)
GET  /api/stocks                → الأسهم
GET  /api/diagnostic            → فحص تشخيصي مفصّل

# التحليل (لكل سهم)
GET  /api/intelligence/<code>   → التحليل الكامل (الأهم)
GET  /api/technical/<code>      → التحليل الفني (43 مؤشر)
GET  /api/fundamental/<code>    → التحليل الأساسي + قيمة عادلة
GET  /api/risk/<code>           → المخاطر المتقدمة (7 فئات)
GET  /api/news/<code>           → الأخبار + materiality
GET  /api/sentiment/<code>      → المعنويات (3 طبقات)
GET  /api/opportunity/<code>    → الفرص المبكرة (5 إشارات)
GET  /api/explain/<code>        → ليه النتيجة كده؟ (explainability)
GET  /api/strategy/<code>/<strat> → تقييم حسب استراتيجية

# الترتيب والفلاتر
GET  /api/ranking               → أفضل 20
GET  /api/rank?min_score=60     → فلاتر متقدمة
GET  /api/filters               → كل الخيارات المتاحة
GET  /api/strategies            → 7 استراتيجيات
GET  /api/opportunities         → كل الفرص المبكرة
GET  /api/sector-stats          → متوسط كل قطاع

# الاختبار والمعايرة
GET  /api/backtest              → نتائج الاختبار التاريخي
GET  /api/stress?scenario=bear  → اختبار ضغط (7 سيناريوهات)
GET  /api/calibration           → حالة المعايرة (GET/POST)

# المحفظة
GET/POST /api/portfolio         → عرض/تعديل المحفظة
GET  /api/portfolio/fit/<code>  → ملاءمة السهم لمحفظتك

# الأقسام
GET  /api/top-movers            → أعلى التحركات
GET  /api/heat                  → خريطة حرارية
GET  /api/sector/<sector>       → أسهم قطاع
GET  /api/search/<q>            → بحث
GET  /api/dashboard             → لوحة التحكم الكاملة

# البيانات
GET  /api/dividends             → 78 توزيع
GET  /api/dividends/stats       → إحصائيات التوزيعات
GET  /api/ai-status             → حالة الذكاء الاصطناعي

POST /api/analyze {code}        → تحليل بالذكاء الاصطناعي
POST /api/chat                  → محادثة
POST /api/portfolio             → تعديل المحفظة
POST /api/calibration           → معايرة الأوزان
```

---

## 🧠 الـ 8 محاور (كلهم من بيانات حقيقية)

| المحور | الدالة | الوزن | مصدر البيانات |
|:---|:---|:---:|:---|
| **التحليل الفني** | `tech_score()` | 18% | 43 مؤشر من TradingView |
| **التحليل الأساسي** | `fundamental_score()` | 22% | P/E, ROE, PB + مقارنة بالقطاع |
| **السيولة** | `liquidity_score()` | 18% | حجم + قيمة سوقية + معدل دوران |
| **الأخبار** | `news_engine()` | 5% | 78 إعلان رسمي من foudalens |
| **المعنويات** | `sentiment_engine()` | 4% | أداء السهم/السوق/القطاع |
| **أمان المخاطرة** | (محور في final_score) | 24% | Beta + تقلب + ديون |
| **ملاءمة المحفظة** | `portfolio_fit()` | 9% | تركّز + تنويع |
| **النتيجة النهائية** | `final_score()` | 100% | مرجّح + خصومات بسقوف |

**⚠️ المعنويات CAP = 25% — ما تتحكمش في القرار أبداً**

---

## 🔑 الدوال الأساسية (في `update_prices.py`)

```python
# طبقة البيانات
validate_value()      → فحص كل رقم قبل قبوله
_quality_of()         → درجة ثقة البيانات 0-100
facts_text()          → تنسيق البيانات للذكاء الاصطناعي
derive_technical()    → استنتاج المؤشرات الناقصة حسابياً

# طبقة التحليل
tech_score()          → فني (5 مكونات)
fundamental_score()   → أساسي (4 مكونات + قيمة عادلة بـ 4 طرق)
liquidity_score()     → سيولة (4 مكونات)
news_engine()         → أخبار (3 مستويات materiality)
sentiment_engine()    → معنويات (3 طبقات)
risk_engine()         → مخاطر (7 فئات + عائد/خطر)
portfolio_fit()       → محفظة (4 مكونات)
opportunity_engine()  → فرص مبكرة (5 إشارات)

# طبقة القرار
final_score()         → النتيجة النهائية (مرجّح + تعديلات)
strategy_score()      → 7 استراتيجيات
explain_score()       → ليه النتيجة كده

# طبقة الاختبار
bt_snapshot()         → لقطة يومية
bt_evaluate()         → قياس بعد ٣+ أيام
bt_benchmark()        → مقارنة مع السوق (alpha)
stress_test()         → 7 سيناريوهات ضغط
apply_calibration()   → معايرة الأوزان
```

---

## 📊 الأوزان المعايرة (v1.1)

```python
AXIS_WEIGHTS = {
    "technical":   0.18,   # فني
    "fundamental": 0.22,   # أساسي
    "liquidity":   0.18,   # سيولة  ← كان 0.10
    "news":        0.05,   # أخبار
    "sentiment":   0.04,   # معنويات ← قاعدة صارمة
    "risk":        0.24,   # أمان   ← كان 0.20
    "portfolio":   0.09,   # محفظة
}
# المجموع = 1.00 ✓

# سقوف الخصومات
risk_pen ≤ 15 نقطة
liq_pen  ≤ 6 نقاط
المجموع  ≤ 22 نقطة
```

---

## 🎯 الاستراتيجيات الـ 7

| المفتاح | الاسم | المدى | أقوى محور |
|:---|:---|:---|:---|
| `swing` | مضاربة | أيام-أسابيع | فني 40% |
| `value` | قيمة | سنة-٣ سنوات | أساسي 45% |
| `growth` | نمو | ١-٣ سنوات | أساسي 40% |
| `income` | دخل | مستمر | أساسي 35% |
| `balanced` | متوازن | ٣-١٢ شهر | أساسي 25% |
| `conservative` | محافظ | ١-٣ سنوات | أمان 28% |
| `aggressive` | جريء | أشهر | فني 32% |

---

## 🛡️ قواعد صارمة — ما تنكسرش

| # | القاعدة |
|:---:|---|
| 1 | **ما نخترعش بيانات** — لو المصدر ما رجعش، نقول "غير متاح" |
| 2 | **المعنويات ما تتحكمش** — الـ CAP عند 25% وما ينزلش |
| 3 | **forward-tracking مش backtest وهمي** — بنقيس من النهاردة بصدق |
| 4 | **كل تعديل في commit واحد** — ممنوع amend متكرر |
| 5 | **شغّل `check_health.sh` قبل أي تعديل** |
| 6 | **أي معايرة لازم يكون ليها سبب موثّق** |
| 7 | **السقوف (caps) موجودة** — الخصومات ما تتراكمش بلا حدود |
| 8 | **الحالات الناقصة بتتقال 45** — مش معناها إيجابي |

---

## 🐛 الأخطاء اللي اتصلحت (للتفادي)

| الخطأ | السبب | الحل |
|:---|:---|:---|
| `p1m` undefined | متغيّر مستخدم قبل تعريفه | تعريفه في أول الدالة |
| `conf_pen` undefined | copy-paste من دالة تانية | حسابه صح في كل دالة |
| `all_axes` crash | ممكن يكون `null` أو نص | حماية بالنوع `isinstance` |
| HTTP 500Gemini | بيانات نصية مكان أرقام | `_f()` في كل محرك |
| Securities null | السوق مقفول | `derive_technical()` يحسب حسابياً |
| قيم علاوة 6000% | ربحية ناقصة | استنتاج + سقف ٣ أضعاف |

---

## 📋 الحالة الحالية (٢٠٢٦-٠٧-٠٧)

```
الأسهم المحللة     252
ثقة البيانات       82.7/100
عمر البيانات       0.8 دقيقة
متوسط النتيجة      38.7/100   (السوق هابط)
القرارات           213 بيع · 28 احتفظ · 11 تجميع
أفضل سهم           EGAL (64.3)
أسوأ أسهم          NDRL (15.5) · SPHT (12.7)
فرص مبكرة         10
مقارنة السوق       أقل من السوق ❌
المعايرة           v1.1
لقطات الاختبار      1
```

---

## ⚠️ ليه 213 "بيع"؟

**السوق المصري هابط فعلاً.** متوسط النتيجة 38.7/100 يعني أغلب الأسهم ضعيفة.

**ده مش bug — النظام بيقول الحقيقة.** لما السوق تعافى، النتيجة هترتفع.

---

## 🚀 الخطوة الجاية

```
⏳ بعد أسبوع: افتح /api/backtest
   هيبقى ~7 لقطات — هنعرف التوصيات بتجيب نتيجة ولا لأ

📋 أول Covid: نعاير الأوزان تاني بناءً على نتائج الاختبار
```

---

## 🔧 للتشغيل من الصفر

```bash
# 1.複製 الملفات
git clone https://github.com/ahmed3zz2020-source/octa-prices.git
cd octa-prices

# 2. keys
export GEMINI_API_KEY="your-key"

# 3. تشغيل محلي
pip install -r requirements.txt
gunicorn update_prices:app --bind 0.0.0.0:8000 --workers 1 --timeout 120

# 4. فحص
./check_health.sh
```

---

## 📞 لو في مشكلة

```bash
# 1. شوف حالة السيرفر
curl https://octa-prices-production-4ccb.up.railway.app/api/diagnostic

# 2. شوف آخر تحديث للبيانات
curl https://octa-prices-production-4ccb.up.railway.app/api/prices | head -c 300

# 3. لو السيرفر قديم
Railway → Settings → Source → Check for updates → Update

# 4. لو كل حاجة بايظة
git checkout update_prices.py   # ارجع لآخر نسخة سليمة
./check_health.sh
```

---

## 📦 النسخ المحفوظة

```
snapshots/update_prices_v1.1_calibrated.py   ← قبل الإصلاح الأخير
snapshots/update_prices_v1.2_final.py       ← ✅ آخر نسخة
```

---

**🐙 OCTA — جاهز للاستخدام الفعلي**

<deliver-assets>
<media type="website" src="https://jxvfkm8kpnrtz.space.minimax.io" name="OCTA — المحرك الكامل" />
</deliver-assets>
